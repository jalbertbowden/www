A Pen created at CodePen.io. You can find this one at http://codepen.io/arjshiv/pen/YqPoGR.

 Custom marker to render a dashed line as part of highcharts