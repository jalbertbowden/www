### Highcharts Legend Highlighter plugin

Legend Highlighter is a plugin for Highcharts.js, which adds a new data series highlight effect to your charts.

You will find more information here : http://sidnet.github.io/highcharts-legend-highlighter/