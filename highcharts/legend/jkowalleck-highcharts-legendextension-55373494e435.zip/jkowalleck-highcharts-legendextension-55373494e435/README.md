# HighchartsExtension: LegendToggle

Extension for Highcharts3 and Highstocks1.3 
to add the Chart some functions:

* legendHide() 
* legendShow() 
* legendToggle() 



## Demo
* http://jsfiddle.net/jnkowa/63kMv/
* http://jsfiddle.net/jnkowa/BnD8D/



## License
see file: LICENSE